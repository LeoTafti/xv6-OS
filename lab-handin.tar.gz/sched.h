#define SCHED_OTHER 0
#define SCHED_FIFO 1
#define SCHED_RR 2

#define PRTY_DFLT 0 //Default priority is lowest