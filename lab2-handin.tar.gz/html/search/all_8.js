var searchData=
[
  ['head',['head',['../bio_8c.html#aa6e692c16f1b909f5cb2a1832cf43430',1,'bio.c']]],
  ['header',['header',['../unionheader.html',1,'header'],['../umalloc_8c.html#a1a2bfaef0959ba21a357a6f8feaa477b',1,'Header():&#160;umalloc.c']]],
  ['holding',['holding',['../defs_8h.html#ac44b13cc76bf4040e3baf34df75ff230',1,'holding(struct spinlock *):&#160;spinlock.c'],['../spinlock_8c.html#aea48df3e5cfb903179ad3dc78ab502d9',1,'holding(struct spinlock *lock):&#160;spinlock.c']]],
  ['hour',['hour',['../structrtcdate.html#ac601418b8ff95c35e8fddb47dd3fc77b',1,'rtcdate']]],
  ['hours',['HOURS',['../lapic_8c.html#a212d0f839f6f7ca43ccde311f93d5892',1,'lapic.c']]]
];
