var searchData=
[
  ['year',['year',['../structrtcdate.html#a143aaaa0a5fcaae876c0af5f135ea5c8',1,'rtcdate::year()'],['../lapic_8c.html#a5871356500f559add06ea81d60331b1b',1,'YEAR():&#160;lapic.c']]],
  ['yield',['yield',['../defs_8h.html#a7cb51f5c2b5cad3766f19eb69c92793b',1,'yield(void):&#160;proc.c'],['../proc_8c.html#a7cb51f5c2b5cad3766f19eb69c92793b',1,'yield(void):&#160;proc.c']]]
];
