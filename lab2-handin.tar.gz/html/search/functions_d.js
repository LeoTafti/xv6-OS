var searchData=
[
  ['namecmp',['namecmp',['../defs_8h.html#a0206c4090dc4bdfd8481e38057d5b2af',1,'namecmp(const char *, const char *):&#160;fs.c'],['../fs_8c.html#ae74f6e5b19a4e7f3e72807ee67141819',1,'namecmp(const char *s, const char *t):&#160;fs.c']]],
  ['namei',['namei',['../defs_8h.html#a29aa723e0b59f069c9eba588fdeb7e5a',1,'namei(char *):&#160;fs.c'],['../fs_8c.html#a9baba030d5bc6e9e20cf8b7d181edf35',1,'namei(char *path):&#160;fs.c']]],
  ['nameiparent',['nameiparent',['../defs_8h.html#a02a47e8fb060db0a29727f29879024cc',1,'nameiparent(char *, char *):&#160;fs.c'],['../fs_8c.html#a5a987ca4f8ffd579b96a8b9a60e61a7c',1,'nameiparent(char *path, char *name):&#160;fs.c']]],
  ['nulterminate',['nulterminate',['../sh_8c.html#a116fd6ef63a4f3a15340502d15ec1ce1',1,'sh.c']]]
];
