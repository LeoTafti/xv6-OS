var searchData=
[
  ['qnext',['qnext',['../structbuf.html#aba5c088c4da07a5ec88edfacdae9b85a',1,'buf']]]
];
