var searchData=
[
  ['cat',['cat',['../cat_8c.html#a90a33618884bcf5e892297879bc016ff',1,'cat.c']]],
  ['chdir',['chdir',['../user_8h.html#abd9c122e4b77f6b137e3ced8b9d9b931',1,'user.h']]],
  ['check_5fextmem_5fmapped',['check_extmem_mapped',['../main_8c.html#abd7aa67c2e6a82e3c33e01609bf84327',1,'main.c']]],
  ['clearpteu',['clearpteu',['../defs_8h.html#a795e27a0cb916cfb41411ebbb9669ddf',1,'clearpteu(pde_t *pgdir, char *uva):&#160;vm.c'],['../vm_8c.html#a795e27a0cb916cfb41411ebbb9669ddf',1,'clearpteu(pde_t *pgdir, char *uva):&#160;vm.c']]],
  ['close',['close',['../user_8h.html#ae152484c890a24e4d9b4980e7b965be0',1,'user.h']]],
  ['cmostime',['cmostime',['../defs_8h.html#a7247ece9501e31d62cffad46ec33d7af',1,'cmostime(struct rtcdate *r):&#160;lapic.c'],['../lapic_8c.html#a7247ece9501e31d62cffad46ec33d7af',1,'cmostime(struct rtcdate *r):&#160;lapic.c']]],
  ['concreate',['concreate',['../usertests_8c.html#a5a12affe4fdfaa172d85da9a6adf98d2',1,'usertests.c']]],
  ['cons_5fgetc',['cons_getc',['../console_8c.html#a53b135d585a564aa1ad542d3c977adec',1,'console.c']]],
  ['consoleinit',['consoleinit',['../console_8c.html#ab508ff0f4db26fe35cd25fa648f9ee75',1,'consoleinit(void):&#160;console.c'],['../defs_8h.html#ab508ff0f4db26fe35cd25fa648f9ee75',1,'consoleinit(void):&#160;console.c']]],
  ['consoleintr',['consoleintr',['../console_8c.html#aad3d6ca39f23bb6d2686d2967e415193',1,'consoleintr(int(*getc)(void)):&#160;console.c'],['../defs_8h.html#a9ec968a6fc407075634fe0e82a9c6862',1,'consoleintr(int(*)(void)):&#160;console.c']]],
  ['consoleread',['consoleread',['../console_8c.html#a28ac85a90987662e306ca8efbfe16074',1,'console.c']]],
  ['consolewrite',['consolewrite',['../console_8c.html#a6af7eb39268127d389792cec37785666',1,'console.c']]],
  ['copyout',['copyout',['../defs_8h.html#a11f5ff2e5bcd16968a88fcbb30db5a10',1,'copyout(pde_t *, uint, void *, uint):&#160;vm.c'],['../vm_8c.html#a532bc3f3e39942c20a471a11cff1a582',1,'copyout(pde_t *pgdir, uint va, void *p, uint len):&#160;vm.c']]],
  ['copyuvm',['copyuvm',['../defs_8h.html#aaa9d4abe019ce435b9a3296be3a2e214',1,'copyuvm(pde_t *, uint):&#160;vm.c'],['../vm_8c.html#ad158860fa206e19f2370eeab852bca7c',1,'copyuvm(pde_t *pgdir, uint sz):&#160;vm.c']]],
  ['cprintf',['cprintf',['../console_8c.html#ab5c1b009763ca6674c08b6241dad015c',1,'cprintf(const char *fmt,...):&#160;console.c'],['../defs_8h.html#ab5c1b009763ca6674c08b6241dad015c',1,'cprintf(const char *fmt,...):&#160;console.c'],['../stdio_8h.html#ab5c1b009763ca6674c08b6241dad015c',1,'cprintf(const char *fmt,...):&#160;console.c']]],
  ['cpunum',['cpunum',['../defs_8h.html#ad07bc98847d46ba9772ab5ad4f52e6ec',1,'cpunum(void):&#160;lapic.c'],['../lapic_8c.html#ad07bc98847d46ba9772ab5ad4f52e6ec',1,'cpunum(void):&#160;lapic.c']]],
  ['cputchar',['cputchar',['../console_8c.html#a506d19d964964f870d943d5ce8d372c1',1,'cputchar(int):&#160;console.c'],['../stdio_8h.html#a957c6cffc0963f9e00e839f6f8af6fb9',1,'cputchar(int c):&#160;console.c']]],
  ['createdelete',['createdelete',['../usertests_8c.html#a425a0efe4f459decf4b5ea14517ab3cf',1,'usertests.c']]],
  ['createtest',['createtest',['../usertests_8c.html#a6773439702f38f3835fb6195f77e001c',1,'usertests.c']]]
];
