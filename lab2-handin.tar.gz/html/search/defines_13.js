var searchData=
[
  ['whitespace',['WHITESPACE',['../monitor_8c.html#abfa0d183e035eb9705b5faec98294d0f',1,'monitor.c']]]
];
