var searchData=
[
  ['sleeping',['SLEEPING',['../proc_8h.html#aa1ced7d2b60040fded3fa873d0c03ba7a488282601451a751e0f0e770b15d4235',1,'proc.h']]]
];
