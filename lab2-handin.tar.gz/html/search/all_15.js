var searchData=
[
  ['v2p',['V2P',['../memlayout_8h.html#a5021188bc7da1304f27e913aee183407',1,'memlayout.h']]],
  ['v2p_5fwo',['V2P_WO',['../memlayout_8h.html#a07c445cd5425fc1d69188d1e6d511e4b',1,'memlayout.h']]],
  ['va_5farg',['va_arg',['../stdarg_8h.html#a81ebe6ea6253b0c6618e29de70fe10eb',1,'stdarg.h']]],
  ['va_5fend',['va_end',['../stdarg_8h.html#acd9b3b9085ec072324c5fdac2b40304e',1,'stdarg.h']]],
  ['va_5flist',['va_list',['../stdarg_8h.html#af53f622e3b6c080daeb167c1955d7ec1',1,'stdarg.h']]],
  ['va_5fstart',['va_start',['../stdarg_8h.html#ade24ac546ea93fde2353ed2db8e89c66',1,'stdarg.h']]],
  ['vaddr',['vaddr',['../structproghdr.html#a6fa1051e19935bbedc5eaf086f5330b4',1,'proghdr']]],
  ['validateint',['validateint',['../usertests_8c.html#a426d02dfb5155266933466f604bed0b2',1,'usertests.c']]],
  ['validatetest',['validatetest',['../usertests_8c.html#a98d8496ecb698b9400831f2718d805c3',1,'usertests.c']]],
  ['vcopyuvm',['vcopyuvm',['../defs_8h.html#a473c3df785e0748949c22ca6b44f8027',1,'vcopyuvm(pde_t *, uint):&#160;vm.c'],['../vm_8c.html#af917b0efb3b8343dab54adbf0fca6e65',1,'vcopyuvm(pde_t *pgdir, uint sz):&#160;vm.c']]],
  ['vcprintf',['vcprintf',['../console_8c.html#a6d5854f463c39b8d25aaa127b216832e',1,'vcprintf(const char *fmt, va_list ap):&#160;console.c'],['../stdio_8h.html#afdbde9526c922803eba3cd7de0ddb12f',1,'vcprintf(const char *fmt, va_list):&#160;console.c']]],
  ['vectors',['vectors',['../trap_8c.html#a3e6e0e8b5ba8014e09de2d9aa3740486',1,'trap.c']]],
  ['ver',['VER',['../lapic_8c.html#a98ed931f97fef7e06e3ea441d0326c67',1,'lapic.c']]],
  ['version',['version',['../structelfhdr.html#abb1c8274f47cfdbbcefe44af2d5c723d',1,'elfhdr::version()'],['../structmpconf.html#ade1055584605c76f4e1134d6631e0afa',1,'mpconf::version()'],['../structmpproc.html#a6d7948bc046404527c0eec71e3e93209',1,'mpproc::version()'],['../structmpioapic.html#a7c6f3d950f89e2b982fd53f7c59681e7',1,'mpioapic::version()']]],
  ['vfprintf',['vfprintf',['../stdio_8h.html#ad47d4ec6003b657fd394ab5d53b4a493',1,'stdio.h']]],
  ['vm_2ec',['vm.c',['../vm_8c.html',1,'']]],
  ['vm_2ed',['vm.d',['../vm_8d.html',1,'']]],
  ['vprintfmt',['vprintfmt',['../printfmt_8c.html#a6434f2b779b5ede2adc31ee4f7d64198',1,'vprintfmt(void(*putch)(int, void *), void *putdat, const char *fmt, va_list ap):&#160;printfmt.c'],['../stdio_8h.html#a1a3d8ef72579cf7f747da074b35026ca',1,'vprintfmt(void(*putch)(int, void *), void *putdat, const char *fmt, va_list):&#160;printfmt.c']]],
  ['vsnprintf',['vsnprintf',['../printfmt_8c.html#a5dba43d9553078b7ce7483bb4be8552f',1,'vsnprintf(char *buf, int n, const char *fmt, va_list ap):&#160;printfmt.c'],['../stdio_8h.html#af0f15310de0217579161669b520de178',1,'vsnprintf(char *str, int size, const char *fmt, va_list):&#160;printfmt.c']]]
];
