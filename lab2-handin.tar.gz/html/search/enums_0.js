var searchData=
[
  ['procstate',['procstate',['../proc_8h.html#aa1ced7d2b60040fded3fa873d0c03ba7',1,'proc.h']]]
];
