var searchData=
[
  ['backcmd',['backcmd',['../structbackcmd.html',1,'']]],
  ['buf',['buf',['../structbuf.html',1,'']]]
];
