var searchData=
[
  ['taskstate',['taskstate',['../structtaskstate.html',1,'']]],
  ['trapframe',['trapframe',['../structtrapframe.html',1,'']]]
];
