var searchData=
[
  ['v2p',['V2P',['../memlayout_8h.html#a5021188bc7da1304f27e913aee183407',1,'memlayout.h']]],
  ['v2p_5fwo',['V2P_WO',['../memlayout_8h.html#a07c445cd5425fc1d69188d1e6d511e4b',1,'memlayout.h']]],
  ['va_5farg',['va_arg',['../stdarg_8h.html#a81ebe6ea6253b0c6618e29de70fe10eb',1,'stdarg.h']]],
  ['va_5fend',['va_end',['../stdarg_8h.html#acd9b3b9085ec072324c5fdac2b40304e',1,'stdarg.h']]],
  ['va_5fstart',['va_start',['../stdarg_8h.html#ade24ac546ea93fde2353ed2db8e89c66',1,'stdarg.h']]],
  ['ver',['VER',['../lapic_8c.html#a98ed931f97fef7e06e3ea441d0326c67',1,'lapic.c']]]
];
