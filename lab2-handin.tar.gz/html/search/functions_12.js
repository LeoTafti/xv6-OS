var searchData=
[
  ['test_5fpage',['test_page',['../main_8c.html#a10b9845e78307b74552f24d252d0370c',1,'main.c']]],
  ['test_5fpage_5falloc',['test_page_alloc',['../main_8c.html#a594e552d73bfe10bfbf45634cc1a2ff4',1,'main.c']]],
  ['test_5fpage_5ffree_5flist',['test_page_free_list',['../main_8c.html#a68d612745a554b88a3cd5e46ca6c7df3',1,'main.c']]],
  ['test_5fpage_5ffree_5flist_5fext',['test_page_free_list_ext',['../main_8c.html#acff8b5dc6d40acd910fd944b7947c0c7',1,'main.c']]],
  ['timerinit',['timerinit',['../defs_8h.html#a49af4bce992b520d5032364d0a4eb8ee',1,'timerinit(void):&#160;timer.c'],['../timer_8c.html#a49af4bce992b520d5032364d0a4eb8ee',1,'timerinit(void):&#160;timer.c']]],
  ['tlb_5finvalidate',['tlb_invalidate',['../defs_8h.html#af91405ff642773a68abda78f01892ab3',1,'tlb_invalidate(pde_t *pgdir, void *va):&#160;vm.c'],['../vm_8c.html#af91405ff642773a68abda78f01892ab3',1,'tlb_invalidate(pde_t *pgdir, void *va):&#160;vm.c']]],
  ['trap',['trap',['../trap_8c.html#a372d166e36c086c91e5f5d81e5fead3a',1,'trap.c']]],
  ['trapret',['trapret',['../proc_8c.html#a6c085102b25a17b9a1a78db5a8be16f9',1,'proc.c']]],
  ['tvinit',['tvinit',['../defs_8h.html#a9e7167b8e20e217c4af4e757f612ba6a',1,'tvinit(void):&#160;trap.c'],['../trap_8c.html#a9e7167b8e20e217c4af4e757f612ba6a',1,'tvinit(void):&#160;trap.c']]]
];
