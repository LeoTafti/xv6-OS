var searchData=
[
  ['gb',['GB',['../types_8h.html#a44172ac633c517cb4c9e278cef36b000',1,'types.h']]]
];
