var searchData=
[
  ['rand',['rand',['../usertests_8c.html#a866c3f5e3e89035c3ba01b22d786d8bc',1,'usertests.c']]],
  ['read',['read',['../user_8h.html#a2d73522d6354b8a141ecfaa9585a0c77',1,'user.h']]],
  ['readi',['readi',['../defs_8h.html#a2415273b06f31f0f2587b7325588a7e4',1,'readi(struct inode *, char *, uint, uint):&#160;fs.c'],['../fs_8c.html#a3aba1fa9f6789d09356aec5b96d91fa8',1,'readi(struct inode *ip, char *dst, uint off, uint n):&#160;fs.c']]],
  ['readline',['readline',['../readline_8c.html#adc634fefff1a9f71c87a04e1eddb8649',1,'readline(const char *prompt):&#160;readline.c'],['../stdio_8h.html#adc634fefff1a9f71c87a04e1eddb8649',1,'readline(const char *prompt):&#160;readline.c']]],
  ['readsb',['readsb',['../defs_8h.html#aff0080b2133027be2e525ca088b40e78',1,'readsb(int dev, struct superblock *sb):&#160;fs.c'],['../fs_8c.html#aff0080b2133027be2e525ca088b40e78',1,'readsb(int dev, struct superblock *sb):&#160;fs.c']]],
  ['readsect',['readsect',['../bootmain_8c.html#ae7ef59ffa082283b72c54e43b7a16351',1,'bootmain.c']]],
  ['readseg',['readseg',['../bootmain_8c.html#af8097ce47ae21ccad1b0afd6f48ef62c',1,'bootmain.c']]],
  ['redircmd',['redircmd',['../sh_8c.html#ad6b34af843c5bc556aac1ad33d1e4517',1,'sh.c']]],
  ['release',['release',['../defs_8h.html#a4f8616948f3dbce65671f666eed1d669',1,'release(struct spinlock *):&#160;spinlock.c'],['../spinlock_8c.html#a1cee376aa9a00e754bf5481cd5f3d97b',1,'release(struct spinlock *lk):&#160;spinlock.c']]],
  ['rinode',['rinode',['../mkfs_8c.html#a3b6cb1258a963010211a8e5ddf99defe',1,'mkfs.c']]],
  ['rmdot',['rmdot',['../usertests_8c.html#a6b22568d42b584ed4b0dc4e2b0677013',1,'usertests.c']]],
  ['rsect',['rsect',['../mkfs_8c.html#a22ea835ad23cd716a962f30e4882ee80',1,'mkfs.c']]],
  ['runcmd',['runcmd',['../sh_8c.html#aedbeff6afe5d4e22330c7e6b5e6df893',1,'sh.c']]]
];
