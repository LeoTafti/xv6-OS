var searchData=
[
  ['gatedesc',['gatedesc',['../structgatedesc.html',1,'']]]
];
