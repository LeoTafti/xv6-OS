var searchData=
[
  ['kalloc',['kalloc',['../defs_8h.html#a3af104ba40b66dcec8363ac5a70907ed',1,'kalloc(void):&#160;kalloc.c'],['../kalloc_8c.html#a3af104ba40b66dcec8363ac5a70907ed',1,'kalloc(void):&#160;kalloc.c']]],
  ['kbdgetc',['kbdgetc',['../console_8c.html#ae0e5224d52563340db794138daec14ca',1,'kbdgetc(void):&#160;kbd.c'],['../kbd_8c.html#ae0e5224d52563340db794138daec14ca',1,'kbdgetc(void):&#160;kbd.c']]],
  ['kbdintr',['kbdintr',['../defs_8h.html#af3d6113fa152781400e1e0e728c55e54',1,'kbdintr(void):&#160;kbd.c'],['../kbd_8c.html#af3d6113fa152781400e1e0e728c55e54',1,'kbdintr(void):&#160;kbd.c']]],
  ['kdecref',['kdecref',['../defs_8h.html#a6bf5aaf3c1623fbc75279a59e7bcadda',1,'kdecref(char *va):&#160;kalloc.c'],['../kalloc_8c.html#a6bf5aaf3c1623fbc75279a59e7bcadda',1,'kdecref(char *va):&#160;kalloc.c']]],
  ['kfree',['kfree',['../defs_8h.html#ae79d6a7d0901b7c081cfded3f916d5bd',1,'kfree(char *):&#160;kalloc.c'],['../kalloc_8c.html#aced59ecf8411235f6dffc065236711a5',1,'kfree(char *v):&#160;kalloc.c']]],
  ['kill',['kill',['../defs_8h.html#ab893e9671d6bfe2b2604002a50639f21',1,'kill(int):&#160;proc.c'],['../proc_8c.html#a650cf0caaaa8b75f653c1c92818d03a4',1,'kill(int pid):&#160;proc.c'],['../user_8h.html#ab893e9671d6bfe2b2604002a50639f21',1,'kill(int):&#160;proc.c']]],
  ['kinit1',['kinit1',['../defs_8h.html#abc7a6a8cb3bcde83697a0c9a61d22d4d',1,'kinit1(void *, void *):&#160;kalloc.c'],['../kalloc_8c.html#a596c07f040e83fd8ea1857f36ffab4fb',1,'kinit1(void *vstart, void *vend):&#160;kalloc.c']]],
  ['kinit2',['kinit2',['../defs_8h.html#aeb265df0f4968b40d175d9e3030d737c',1,'kinit2(void *, void *):&#160;kalloc.c'],['../kalloc_8c.html#a8efe9094969255a41fbdaaee820bd478',1,'kinit2(void *vstart, void *vend):&#160;kalloc.c']]],
  ['kinsert',['kinsert',['../defs_8h.html#a654f70eb00920123570701eb561a2dc3',1,'kinsert(pde_t *pgdir, struct page_info *pp, char *va, int perm):&#160;kalloc.c'],['../kalloc_8c.html#a654f70eb00920123570701eb561a2dc3',1,'kinsert(pde_t *pgdir, struct page_info *pp, char *va, int perm):&#160;kalloc.c']]],
  ['klookup',['klookup',['../defs_8h.html#a9541ef47936123e59217b7379357e8dd',1,'klookup(pde_t *pgdir, void *va, pte_t **pte_store):&#160;kalloc.c'],['../kalloc_8c.html#a9541ef47936123e59217b7379357e8dd',1,'klookup(pde_t *pgdir, void *va, pte_t **pte_store):&#160;kalloc.c']]],
  ['kmarkused',['kmarkused',['../defs_8h.html#a2f9e9c87a7ea58bdb65958e521969111',1,'kmarkused(void *, void *):&#160;kalloc.c'],['../kalloc_8c.html#a8d991b34ccd50196cc19720cd4495e2c',1,'kmarkused(void *vstart, void *vend):&#160;kalloc.c']]],
  ['kremove',['kremove',['../defs_8h.html#a9ba746e6dc1f08b3cf2825c278d09a41',1,'kremove(pde_t *pgdir, void *va):&#160;kalloc.c'],['../kalloc_8c.html#a9ba746e6dc1f08b3cf2825c278d09a41',1,'kremove(pde_t *pgdir, void *va):&#160;kalloc.c']]],
  ['kvmalloc',['kvmalloc',['../defs_8h.html#a893bf6891e427f310b43981bf8e737ea',1,'kvmalloc(void):&#160;vm.c'],['../vm_8c.html#a893bf6891e427f310b43981bf8e737ea',1,'kvmalloc(void):&#160;vm.c']]]
];
