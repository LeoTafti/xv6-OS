var searchData=
[
  ['validateint',['validateint',['../usertests_8c.html#a426d02dfb5155266933466f604bed0b2',1,'usertests.c']]],
  ['validatetest',['validatetest',['../usertests_8c.html#a98d8496ecb698b9400831f2718d805c3',1,'usertests.c']]],
  ['vcopyuvm',['vcopyuvm',['../defs_8h.html#a473c3df785e0748949c22ca6b44f8027',1,'vcopyuvm(pde_t *, uint):&#160;vm.c'],['../vm_8c.html#af917b0efb3b8343dab54adbf0fca6e65',1,'vcopyuvm(pde_t *pgdir, uint sz):&#160;vm.c']]],
  ['vcprintf',['vcprintf',['../console_8c.html#a6d5854f463c39b8d25aaa127b216832e',1,'vcprintf(const char *fmt, va_list ap):&#160;console.c'],['../stdio_8h.html#afdbde9526c922803eba3cd7de0ddb12f',1,'vcprintf(const char *fmt, va_list):&#160;console.c']]],
  ['vfprintf',['vfprintf',['../stdio_8h.html#ad47d4ec6003b657fd394ab5d53b4a493',1,'stdio.h']]],
  ['vprintfmt',['vprintfmt',['../printfmt_8c.html#a6434f2b779b5ede2adc31ee4f7d64198',1,'vprintfmt(void(*putch)(int, void *), void *putdat, const char *fmt, va_list ap):&#160;printfmt.c'],['../stdio_8h.html#a1a3d8ef72579cf7f747da074b35026ca',1,'vprintfmt(void(*putch)(int, void *), void *putdat, const char *fmt, va_list):&#160;printfmt.c']]],
  ['vsnprintf',['vsnprintf',['../printfmt_8c.html#a5dba43d9553078b7ce7483bb4be8552f',1,'vsnprintf(char *buf, int n, const char *fmt, va_list ap):&#160;printfmt.c'],['../stdio_8h.html#af0f15310de0217579161669b520de178',1,'vsnprintf(char *str, int size, const char *fmt, va_list):&#160;printfmt.c']]]
];
