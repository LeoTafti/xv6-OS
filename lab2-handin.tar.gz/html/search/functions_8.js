var searchData=
[
  ['holding',['holding',['../defs_8h.html#ac44b13cc76bf4040e3baf34df75ff230',1,'holding(struct spinlock *):&#160;spinlock.c'],['../spinlock_8c.html#aea48df3e5cfb903179ad3dc78ab502d9',1,'holding(struct spinlock *lock):&#160;spinlock.c']]]
];
