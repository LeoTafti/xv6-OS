var searchData=
[
  ['zombie',['ZOMBIE',['../proc_8h.html#aa1ced7d2b60040fded3fa873d0c03ba7a5dfb36109b24f39d54d5c3f48f53def8',1,'proc.h']]]
];
