var searchData=
[
  ['xint',['xint',['../mkfs_8c.html#a0cb088f1b4dabee9a6056b88a8f813ef',1,'mkfs.c']]],
  ['xshort',['xshort',['../mkfs_8c.html#ac6dbbb3aaeee7114cf795be284be08ce',1,'mkfs.c']]]
];
