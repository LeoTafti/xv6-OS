var searchData=
[
  ['inode',['inode',['../structinode.html',1,'']]],
  ['ioapic',['ioapic',['../structioapic.html',1,'']]]
];
