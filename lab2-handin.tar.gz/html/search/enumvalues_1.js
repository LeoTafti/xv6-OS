var searchData=
[
  ['fd_5finode',['FD_INODE',['../structfile.html#adcfd105f46b2868a7694fa7f38de263faa5d8c5e0d95ed88367e96ecebfdf326d',1,'file']]],
  ['fd_5fnone',['FD_NONE',['../structfile.html#adcfd105f46b2868a7694fa7f38de263fa224e095442d50a6bd1058fd742fb68c7',1,'file']]],
  ['fd_5fpipe',['FD_PIPE',['../structfile.html#adcfd105f46b2868a7694fa7f38de263fa59fcf59caf6e70c3cc3cc48291b89752',1,'file']]]
];
