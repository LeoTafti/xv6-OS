var searchData=
[
  ['x',['x',['../unionheader.html#a2f321dbb657408f93d0c585f55951bdb',1,'header']]],
  ['x1',['X1',['../lapic_8c.html#a1964818ccd90a6173ea48cecb652feeb',1,'lapic.c']]],
  ['x86_2eh',['x86.h',['../x86_8h.html',1,'']]],
  ['xchecksum',['xchecksum',['../structmpconf.html#a499447fb50cb158a848f66f124dd8f8d',1,'mpconf']]],
  ['xint',['xint',['../mkfs_8c.html#a0cb088f1b4dabee9a6056b88a8f813ef',1,'mkfs.c']]],
  ['xlength',['xlength',['../structmpconf.html#adbda8ec5a43970662e7eab8f8da11817',1,'mpconf']]],
  ['xshort',['xshort',['../mkfs_8c.html#ac6dbbb3aaeee7114cf795be284be08ce',1,'mkfs.c']]]
];
