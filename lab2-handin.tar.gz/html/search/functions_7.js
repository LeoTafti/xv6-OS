var searchData=
[
  ['getcallerpcs',['getcallerpcs',['../defs_8h.html#a4105de9e2969515d6c6c795c4386f69f',1,'getcallerpcs(void *, uint *):&#160;defs.h'],['../spinlock_8c.html#a6ac35304ea80f01086b47edcc2328010',1,'getcallerpcs(void *v, uint pcs[]):&#160;spinlock.c']]],
  ['getchar',['getchar',['../console_8c.html#a3e29caa20f7cffe18f410f01278905a8',1,'getchar(void):&#160;console.c'],['../stdio_8h.html#a3e29caa20f7cffe18f410f01278905a8',1,'getchar(void):&#160;console.c']]],
  ['getcmd',['getcmd',['../sh_8c.html#a0ee5a9418fea2f92036f5367a4101fe8',1,'sh.c']]],
  ['getpid',['getpid',['../user_8h.html#a939cb25a305fe68aad9b365077f1a8c7',1,'user.h']]],
  ['gets',['gets',['../ulib_8c.html#a3702e71383a007c873d8e7b84dcbe62a',1,'gets(char *buf, int max):&#160;ulib.c'],['../user_8h.html#abab901a6ac270dc88187de0ea891a202',1,'gets(char *, int max):&#160;ulib.c']]],
  ['gettoken',['gettoken',['../sh_8c.html#aaf1dedac6db801eab8d23f2acb3b1272',1,'sh.c']]],
  ['grep',['grep',['../grep_8c.html#aefb6587871b683544f860d4e2b518718',1,'grep.c']]],
  ['growproc',['growproc',['../defs_8h.html#acb02e9289fb8a1017c3455b137a9bccd',1,'growproc(int):&#160;proc.c'],['../proc_8c.html#a9c16214741f4fcd088e5eea468709328',1,'growproc(int n):&#160;proc.c']]]
];
