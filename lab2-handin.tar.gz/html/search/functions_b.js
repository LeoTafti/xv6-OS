var searchData=
[
  ['lapiceoi',['lapiceoi',['../defs_8h.html#a42fdd0783bbeb7cdc646d360191cdcac',1,'lapiceoi(void):&#160;lapic.c'],['../lapic_8c.html#a42fdd0783bbeb7cdc646d360191cdcac',1,'lapiceoi(void):&#160;lapic.c']]],
  ['lapicinit',['lapicinit',['../defs_8h.html#a6b48a1e50acc73cb3e70a65774c87392',1,'lapicinit(void):&#160;lapic.c'],['../lapic_8c.html#a6b48a1e50acc73cb3e70a65774c87392',1,'lapicinit(void):&#160;lapic.c']]],
  ['lapicstartap',['lapicstartap',['../defs_8h.html#ae46b07b96e4429fa85738ac2fe1768a0',1,'lapicstartap(uchar, uint):&#160;lapic.c'],['../lapic_8c.html#a54df00c792282426648d2876835958fa',1,'lapicstartap(uchar apicid, uint addr):&#160;lapic.c']]],
  ['link',['link',['../user_8h.html#a61214ce61efc8c5c9171007c47c0f16b',1,'user.h']]],
  ['linktest',['linktest',['../usertests_8c.html#a4eeee588d4689a58fc140a7d5d7b0608',1,'usertests.c']]],
  ['linkunlink',['linkunlink',['../usertests_8c.html#a1740f29f4ce6d3060fd79a9312edc315',1,'usertests.c']]],
  ['listcmd',['listcmd',['../sh_8c.html#a7baebb9c63e5150e27491823db9d1cdb',1,'sh.c']]],
  ['loaduvm',['loaduvm',['../defs_8h.html#a8a149272578e00e0ce70480004640679',1,'loaduvm(pde_t *, char *, struct inode *, uint, uint):&#160;vm.c'],['../vm_8c.html#a201acc8337a2893268b61ea5a1ee0d53',1,'loaduvm(pde_t *pgdir, char *addr, struct inode *ip, uint offset, uint sz):&#160;vm.c']]],
  ['log_5fwrite',['log_write',['../defs_8h.html#a270d0050dc50965f4f851717841ad33c',1,'log_write(struct buf *):&#160;log.c'],['../log_8c.html#a7eacb0fbebe5ce4c7d3ddea15908b13d',1,'log_write(struct buf *b):&#160;log.c']]],
  ['ls',['ls',['../ls_8c.html#a0dd2caa6531a27dcd755c46e814b63af',1,'ls.c']]]
];
